"""Strategy rules: each returns a target weight series in [0, 1] (long-only, no leverage).

The weight at date t uses only data up to and including the close of t. The
backtester applies it from the next bar, so nothing here may look ahead.

Chosen from research/deep-scan-v2.md (strongest published evidence that fits NSE
delivery, daily bars, low turnover):
  1. tsmom      time-series momentum (Moskowitz, Ooi & Pedersen 2012)
  2. ma_filter  long moving-average trend filter (Faber 2007)
  3. *_vt       volatility-targeting overlay (Moreira & Muir 2017; Harvey et al. 2018)
  4. markov_regime  3-state (bear/sideways/bull) Markov chain on trailing returns, with
                the transition matrix rebuilt each day from past days only (A153,
                Akhil's video idea; an UNTESTED candidate until the gate says otherwise)
  5. sma_cross  the a8 fast/slow SMA crossover, kept as the NEGATIVE CONTROL that the
                gate must reject on data without a planted trend.
Research code only. Not advice; paper trading only.
"""
from __future__ import annotations

from itertools import product
from typing import Callable

import numpy as np
import pandas as pd

Strategy = Callable[..., pd.Series]


def hold(close: pd.Series) -> pd.Series:
    """Always fully invested (A163 gold leg: buy once, hold; no trades, no DP charges)."""
    return pd.Series(1.0, index=close.index)


def tsmom(close: pd.Series, lookback: int = 252) -> pd.Series:
    """1 when the trailing `lookback`-day return is positive, else 0 (cash)."""
    past = close / close.shift(lookback) - 1
    return (past > 0).astype(float).where(past.notna(), 0.0)


def ma_filter(close: pd.Series, window: int = 200) -> pd.Series:
    sma = close.rolling(window).mean()
    return (close > sma).astype(float).where(sma.notna(), 0.0)


def sma_cross(close: pd.Series, fast: int = 10, slow: int = 50) -> pd.Series:
    f, s = close.rolling(fast).mean(), close.rolling(slow).mean()
    return (f > s).astype(float).where(s.notna(), 0.0)


def ema_cross(close: pd.Series, fast: int = 9, slow: int = 21) -> pd.Series:
    """Long (1) while the fast EMA is above the slow EMA, else cash. Same idea as the LuxAlgo video Akhil
    shared on 12 Nov 2026 ("An EMA Strategy That Makes $250K A Month?"); its claims are unverified, so it
    goes through gate.py like every other strategy. EMAs use only past bars (ewm with adjust=False)."""
    f = close.ewm(span=fast, adjust=False).mean()
    s = close.ewm(span=slow, adjust=False).mean()
    w = (f > s).astype(float)
    w.iloc[:slow] = 0.0  # warm-up: no signal until the slow EMA has `slow` bars
    return w


def regime_filter(close: pd.Series, trend: int = 200, vol_window: int = 20,
                  vol_cap: float | None = None) -> pd.Series:
    """A168 regime: 1 in an uptrend (close above its `trend`-day average) and, if `vol_cap`
    is set, calm (annualised realised volatility below it); otherwise 0. Past data only."""
    sma = close.rolling(trend).mean()
    up = close > sma
    if vol_cap is not None:
        rv = close.pct_change().rolling(vol_window).std() * np.sqrt(252)
        up &= rv < vol_cap
    return up.astype(float).where(sma.notna(), 0.0)


def vol_target(weight: pd.Series, close: pd.Series, target: float = 0.12,
               window: int = 20, band: float = 0.10) -> pd.Series:
    """Scale `weight` by target / realised vol (capped at 1) with a no-trade band.

    The band stops tiny daily rebalances that STT would eat.
    """
    rv = close.pct_change().rolling(window).std() * np.sqrt(252)
    raw = (weight * (target / rv).clip(upper=1.0)).fillna(0.0).to_numpy()
    out = np.zeros_like(raw)
    cur = 0.0
    for i, w in enumerate(raw):
        if w == 0.0 or abs(w - cur) > band:
            cur = w
        out[i] = cur
    return pd.Series(out, index=weight.index)


def tsmom_vt(close: pd.Series, lookback: int = 252, target: float = 0.12) -> pd.Series:
    return vol_target(tsmom(close, lookback), close, target)


def ma_filter_vt(close: pd.Series, window: int = 200, target: float = 0.12) -> pd.Series:
    return vol_target(ma_filter(close, window), close, target)


BEAR, SIDE, BULL = 0, 1, 2


def regime_states(close: pd.Series, window: int = 20, threshold: float = 0.05) -> pd.Series:
    """Label each day by its trailing `window`-day return: bull (>= +thr), bear (<= -thr),
    else sideways. NaN until `window` days exist. Uses data up to that day only."""
    r = close / close.shift(window) - 1
    s = pd.Series(SIDE, index=close.index, dtype=float)
    s[r >= threshold] = BULL
    s[r <= -threshold] = BEAR
    return s.where(r.notna())


def markov_matrix(states: pd.Series) -> np.ndarray:
    """3x3 row-stochastic day-to-day transition matrix from a state sequence.
    Rows with no observations are uniform (no information)."""
    s = states.dropna().astype(int).to_numpy()
    m = np.zeros((3, 3))
    np.add.at(m, (s[:-1], s[1:]), 1.0)
    rows = m.sum(axis=1, keepdims=True)
    return np.where(rows > 0, m / np.where(rows > 0, rows, 1.0), 1.0 / 3)


def markov_regime(close: pd.Series, window: int = 20, threshold: float = 0.05) -> pd.Series:
    """Long-only weight = clip(P(bull tomorrow) - P(bear tomorrow), 0, 1).

    Walk-forward: on day t the counts hold only transitions s[i-1] -> s[i] with i <= t
    (both states known at t's close), so no future bar is used. Cash when the current
    state's row has no history yet.
    """
    st = regime_states(close, window, threshold).to_numpy()
    counts = np.zeros((3, 3))
    out = np.zeros(len(st))
    prev = np.nan
    for i, cur in enumerate(st):
        if np.isnan(cur):
            continue
        c = int(cur)
        if not np.isnan(prev):
            counts[int(prev), c] += 1.0
        row = counts[c]
        n = row.sum()
        if n > 0:
            out[i] = min(max((row[BULL] - row[BEAR]) / n, 0.0), 1.0)
        prev = cur
    return pd.Series(out, index=close.index)


# Every grid has an even number (>= 4) of configs: with an odd N the median OOS rank
# gives logit 0 and biases PBO upward (N=3 -> chance PBO of 2/3 instead of 1/2).
REGISTRY: dict[str, tuple[Strategy, dict[str, list]]] = {
    "hold":         (hold,         {}),
    "tsmom":        (tsmom,        {"lookback": [63, 126, 189, 252]}),
    "ma_filter":    (ma_filter,    {"window": [50, 100, 150, 200]}),
    "tsmom_vt":     (tsmom_vt,     {"lookback": [126, 252], "target": [0.10, 0.15]}),
    "ma_filter_vt": (ma_filter_vt, {"window": [150, 200], "target": [0.10, 0.15]}),
    "markov_regime": (markov_regime, {"window": [20, 40], "threshold": [0.03, 0.05]}),
    "sma_cross":    (sma_cross,    {"fast": [5, 10, 20], "slow": [50, 100]}),
    "ema_cross":    (ema_cross,    {"fast": [9, 12], "slow": [21, 50]}),
    "regime_filter": (regime_filter, {"trend": [100, 200], "vol_cap": [None, 0.20]}),
}


def param_grid(name: str) -> list[dict]:
    _, grid = REGISTRY[name]
    keys = list(grid)
    return [dict(zip(keys, vals)) for vals in product(*(grid[k] for k in keys))]


def weights(name: str, close: pd.Series, **params) -> pd.Series:
    fn, _ = REGISTRY[name]
    return fn(close, **params)
